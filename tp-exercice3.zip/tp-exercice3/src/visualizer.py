import seaborn as sns
import matplotlib.pyplot as plt

class TemperatureVisualizer:
    def __init__(self, data):
        self.data = data

    def plot_boxplot(self, regions):
        plt.figure(figsize=(10, 6))
        sns.boxplot(x='Region', y='AvgTemperature', data=self.data[self.data['Region'].isin(regions)])
        plt.title('Comparaison des températures entre différentes régions')
        plt.savefig('outputs/graphs/boxplot.png')  # Sauvegarder le graphique
        plt.show()

    def plot_heatmap(self, city):
        # Filtrer les données pour la ville sélectionnée
        city_data = self.data[self.data['City'].str.lower() == city.lower()]

        # Vérifier si la ville existe
        if city_data.empty:
            print(f"⚠️ Aucune donnée trouvée pour '{city}'. Vérifie l'orthographe.")
            print("Villes disponibles :", self.data['City'].unique())
            return

        # Créer le pivot table pour la heatmap
        heatmap_data = city_data.pivot_table(
            index="Year", columns="Month", values="AvgTemperature", aggfunc="mean"
        )

        # Vérifier s'il y a des valeurs NaN
        if heatmap_data.isnull().all().all():
            print(f"⚠️ Pas de données valides pour '{city}' après pivot.")
            return

        # Tracer la heatmap
        plt.figure(figsize=(12, 8))
        sns.heatmap(heatmap_data, cmap="coolwarm", annot=True, fmt=".1f", linewidths=0.5)

        # Ajouter un titre
        plt.title(f'Heatmap des températures moyennes par mois à {city}', fontsize=14)
        plt.xlabel("Mois")
        plt.ylabel("Année")

        # Sauvegarder l'image
        plt.savefig(f'outputs/graphs/heatmap_{city}.png')
        plt.show()

    def plot_scatter_latitude(self, cities):
        """
        Affiche la relation entre température et latitude pour une liste de villes spécifiques.
        """
        city_data = self.data[self.data["City"].isin(cities)]

        plt.figure(figsize=(10, 6))
        sns.scatterplot(x="Latitude", y="AvgTemperature", data=city_data, alpha=0.5)

        # Ajouter une courbe de régression
        sns.regplot(x="Latitude", y="AvgTemperature", data=city_data, scatter=False, color="red")

        plt.xlabel("Latitude")
        plt.ylabel("Température Moyenne (°F)")
        plt.title("Relation entre la température moyenne et la latitude")

        # Sauvegarder l'image
        plt.savefig("outputs/graphs/scatter_latitude.png")
        plt.show()

    def plot_violin_extreme_temperatures(self, extreme_data):
        plt.figure(figsize=(10, 6))
        sns.violinplot(x='Year', y='AvgTemperature', data=extreme_data)
        plt.title('Distribution des températures extrêmes par année')
        plt.savefig('outputs/graphs/violin_extreme.png')  # Sauvegarder le graphique
        plt.show()