from temperature_data import TemperatureData
from visualizer import TemperatureVisualizer

# Charger les données
temperature_data = TemperatureData('../data/city_temperature.csv')
data = temperature_data.get_data()
# Ajouter les latitudes
temperature_data.add_latitude()

# Visualiser les données
visualizer = TemperatureVisualizer(data)

# 1. Comparaison des températures entre plusieurs régions
regions = ['Africa', 'Asia', 'Europe', 'North America', 'South America']
visualizer.plot_boxplot(regions)

# 2. Heatmap des températures par mois pour une ville donnée
visualizer.plot_heatmap('Boston')

# 3. Relation entre la température et la latitude des villes
cities = ["Algiers", "Tokyo", "Paris", "New York", "São Paulo"]

# Vérifier si les latitudes sont bien attribuées
city_latitudes = temperature_data.get_cities_latitudes(cities)
print("Latitudes des villes sélectionnées :\n", city_latitudes)

# Visualiser la relation entre température et latitude
visualizer = TemperatureVisualizer(data)
visualizer.plot_scatter_latitude(cities)

# 4. Analyse des températures extrêmes
extreme_data = temperature_data.filter_extreme_temperatures()
visualizer.plot_violin_extreme_temperatures(extreme_data)