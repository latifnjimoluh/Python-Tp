import pandas as pd

class TemperatureData:
    def __init__(self, file_path):
        self.data = pd.read_csv(file_path)
        self.clean_data()

    def clean_data(self):
        # Nettoyer les données si nécessaire
        self.data = self.data.dropna()

    def get_data(self):
        return self.data

    def filter_extreme_temperatures(self):
        # Filtrer les températures extrêmes
        return self.data[(self.data['AvgTemperature'] < -10) | (self.data['AvgTemperature'] > 40)]
    
    def add_latitude(self):
        """
        Ajoute les latitudes manuellement en fonction des villes connues.
        """
        latitudes = {
            "Algiers": 36.75,
            "Tokyo": 35.68,
            "Paris": 48.85,
            "New York": 40.71,
            "São Paulo": -23.55
        }

        # Ajoute la colonne Latitude avec 0 par défaut pour éviter les KeyError
        self.data["Latitude"] = self.data["City"].map(latitudes).fillna(0)

    def get_cities_latitudes(self, cities):
        """
        Renvoie les latitudes des villes spécifiées.
        """
        filtered_data = self.data[self.data["City"].isin(cities)][["City", "Latitude"]].drop_duplicates()

        # Vérifie si des villes sont manquantes et les affiche
        missing_cities = set(cities) - set(filtered_data["City"].unique())
        if missing_cities:
            print(f"⚠️ Attention : Ces villes ne sont pas dans le dataset ou n'ont pas de latitude : {missing_cities}")

        return filtered_data